import { FavouriteComponent } from './post/main/favourite/favourite.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { HomeComponent } from './post/main/home/home.component';
import { RegisterComponent } from './auth/components/register/register.component';
import { LoginComponent } from './auth/components/login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  {path:'home', component: HomeComponent},
  {path:'fav', component: FavouriteComponent},
  {path:'**' , component: NotfoundComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
