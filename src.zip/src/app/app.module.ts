import { PostModule } from './post/post.module';
import { AuthModule } from './auth/auth.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, NgModel } from '@angular/forms';
import { AngularFireModule } from '@angular/fire';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import 'firebase/firestore';
import { AngularFirestore, AngularFirestoreModule } from '@angular/fire/firestore';
import{ AngularFireAuthModule }from '@angular/fire/auth';
import { NotfoundComponent } from './notfound/notfound.component';

@NgModule({
  declarations: [
    AppComponent, 
    NotfoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgModel,
    FormsModule,
    AuthModule,
    PostModule,
    AngularFireModule.initializeApp({
      apiKey: "AIzaSyB_tm2uZlFcPibkrlRg_S8iwuPqlNjj6qs",
    authDomain: "socialnetwork-1babf.firebaseapp.com",
    databaseURL: "https://socialnetwork-1babf.firebaseio.com",
    projectId: "socialnetwork-1babf",
    storageBucket: "socialnetwork-1babf.appspot.com",
    messagingSenderId: "575358909755",
    appId: "1:575358909755:web:c4b7ad71f999ef217f4b1e",
    measurementId: "G-8E3ZN8MK7K"
    }),
    AngularFireAuthModule,
    AngularFirestoreModule,
    
  ],
  providers: [AngularFirestore],
  bootstrap: [AppComponent]
})
export class AppModule { }
