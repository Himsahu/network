import { AuthService } from './../../../service/auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  constructor( private as : AuthService , private router : Router) { }

  ngOnInit(): void {
  }
  errorMessage: string ="";
  message: string="Wrong Credentials";
  
  login(form: NgForm)
  {  
    this.as.login(form.value.Emailid, form.value.Password)
    .then(data =>{this.router.navigate(['/home'])})
    .catch(err => this.errorMessage=this.message);
  }

}
