import { UserService } from './../../../service/user.service';
import { AuthService } from './../../../service/auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  errorMsg: string ="";
  constructor(private as : AuthService, private router: Router , private user: UserService) { }

  ngOnInit(): void {
  }

  register(form)
  { 
    this.as.register(form.value.Emailid,form.value.Password)
    .then(data =>
      {
           this.user.addNewUser(data.user.uid, form.value.Emailid)
           this.errorMsg=''
           this.router.navigate(['/'])
      })
    .catch(err => this.errorMsg=err);
  }
}
