import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './main/home/home.component';
import { FavouriteComponent } from './main/favourite/favourite.component';



@NgModule({
  declarations: [HomeComponent, FavouriteComponent],
  imports: [
    CommonModule
  ]
})
export class PostModule { }
