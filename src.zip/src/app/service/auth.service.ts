import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor( private fauth: AngularFireAuth) { }
  login(username: string, password: string )
  {
    return this.fauth.signInWithEmailAndPassword(username,password);
  }

  register(email: string, password: string )
  {
    return this.fauth.createUserWithEmailAndPassword(email,password);
  }
}
